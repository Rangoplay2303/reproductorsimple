import tkinter as tk 
from tkinter import PhotoImage
from tkinter import filedialog 
import pygame
import os 

# Inicializamos el mezclador de pygame 
pygame.mixer.init()

# Función para reproducir la canción 
def play_cancion():
    if not pygame.mixer.music.get_busy():
        pygame.mixer.music.load("cancion.mp3")
        pygame.mixer.music.play()

# Función para detener la canción
def stop_cancion():
    pygame.mixer.music.stop()

# Función para ajustar el volumen
def set_volumen(volumen):
    # Convertimos el volumen de 0-100 a 0.0-1.0
    pygame.mixer.music.set_volume(int(volumen) / 100)

# Creamos la ventana principal de tkinter
root = tk.Tk()
root.title("Hollow Purple")
root.geometry("300x400")

# Cargar y mostrar la imagen del cover
cover_imagen = PhotoImage(file="cover.png")
cover_label = tk.Label(root, image=cover_imagen)
cover_label.pack(pady=20)

# Crear botón Play
Play_boton = tk.Button(root, text="Reproducir", command=play_cancion)
Play_boton.pack(pady=20)

# Crear botón Detener
detener_boton = tk.Button(root, text="Detener", command=stop_cancion)
detener_boton.pack(pady=10)

# Crear slider para el volumen
volumen_slider = tk.Scale(root, from_=0, to=100, orient=tk.HORIZONTAL, label="Volumen", command=set_volumen)
volumen_slider.set(50)  # Establecer el volumen inicial al 50%
volumen_slider.pack(pady=20)

# Comenzar el bucle del programa
root.mainloop()
pygame.mixer.quit()
